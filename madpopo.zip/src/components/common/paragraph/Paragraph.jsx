import React from "react";

const Paragraph = ({ paragraph }) => {
  return <p className="commonPara">{paragraph}</p>;
};

export default Paragraph;
