import React from "react";

const ClickButton = () => {
  return <div>ClickButton</div>;
};

export default ClickButton;
