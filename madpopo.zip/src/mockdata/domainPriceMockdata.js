const domainPriceData = [
    {
    currency: ".in",
    price: "₹84.12 /yr",
    originalPrice: "200",
    },
    {
    currency: ".online",
    price: "₹84.12 /yr",
    originalPrice: "200",
    },
    {
    currency: ".info",
    price: "₹884.61 /yr",
    originalPrice: "1500",
    },
    {
    currency: ".tech",
    price: "₹453.38 /yr",
    originalPrice: "1500",
    },
    {
    currency: ".name",
    price: "₹453.38 /yr",
    originalPrice: "1500",
    },
    {
        currency: ".shop",
    price: "₹453.38 /yr",
    originalPrice: "1500",
    },
]

export default domainPriceData;